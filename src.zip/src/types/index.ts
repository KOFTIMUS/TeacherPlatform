// Shared TypeScript types will be defined here.

export {};
